var searchData=
[
  ['high_5fvoltage_5flevel',['high_voltage_level',['../struct_smpt__get__stim__status__ack.html#aa3de3dca5a7ba08e79064483f59a33de',1,'Smpt_get_stim_status_ack::high_voltage_level()'],['../struct_smpt__ll__init.html#aa3de3dca5a7ba08e79064483f59a33de',1,'Smpt_ll_init::high_voltage_level()']]]
];
