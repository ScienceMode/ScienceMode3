var searchData=
[
  ['main_5fstatus',['main_status',['../struct_smpt__get__main__status__ack.html#a9b043617df7dea27f0ce113de0491995',1,'Smpt_get_main_status_ack']]],
  ['major',['major',['../struct_smpt__version.html#a5bd4e4c943762926c8f653b6224cced2',1,'Smpt_version']]],
  ['mid_2dlevel_20stimulation',['Mid-level stimulation',['../mid_level.html',1,'']]],
  ['minor',['minor',['../struct_smpt__version.html#ae2f416b0a34b7beb4ed3873d791ac393',1,'Smpt_version']]],
  ['modify_5fdemux',['modify_demux',['../struct_smpt__ll__channel__config.html#a85e4232f03b9788b61f56298006a2599',1,'Smpt_ll_channel_config']]]
];
