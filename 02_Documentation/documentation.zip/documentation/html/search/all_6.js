var searchData=
[
  ['general',['General',['../general.html',1,'']]],
  ['getting_20started',['Getting started',['../page_started.html',1,'']]]
];
