var searchData=
[
  ['rehamove3',['RehaMove3',['../device.html',1,'']]],
  ['ramp',['ramp',['../struct_smpt__ml__channel__config.html#a87d643afd5866103df2fa31926ba02e4',1,'Smpt_ml_channel_config']]],
  ['read_5frow_5fcount',['read_row_count',['../struct_packet__input__buffer.html#a2e12889b1575b9ea48868c200f85e9ab',1,'Packet_input_buffer']]],
  ['requests',['requests',['../struct_smpt__cmd__list.html#a75f38376ba5e84ab1247960e9ec69aae',1,'Smpt_cmd_list']]],
  ['requests_5fcurrent_5findex',['requests_current_index',['../struct_smpt__cmd__list.html#afc3994b5ffab5b646ac03a5f97a63e0d',1,'Smpt_cmd_list']]],
  ['requests_5fexpected_5findex',['requests_expected_index',['../struct_smpt__cmd__list.html#a7abeb5a156adf68f6fec677043697285',1,'Smpt_cmd_list']]],
  ['result',['result',['../struct_smpt__ack.html#a5be7912a3f3660b47e6f68740e3a5562',1,'Smpt_ack::result()'],['../struct_smpt__get__version__ack.html#a5be7912a3f3660b47e6f68740e3a5562',1,'Smpt_get_version_ack::result()'],['../struct_smpt__get__device__id__ack.html#a5be7912a3f3660b47e6f68740e3a5562',1,'Smpt_get_device_id_ack::result()'],['../struct_smpt__get__battery__status__ack.html#a5be7912a3f3660b47e6f68740e3a5562',1,'Smpt_get_battery_status_ack::result()'],['../struct_smpt__get__stim__status__ack.html#a5be7912a3f3660b47e6f68740e3a5562',1,'Smpt_get_stim_status_ack::result()'],['../struct_smpt__get__main__status__ack.html#a5be7912a3f3660b47e6f68740e3a5562',1,'Smpt_get_main_status_ack::result()'],['../struct_smpt__ll__init__ack.html#a5be7912a3f3660b47e6f68740e3a5562',1,'Smpt_ll_init_ack::result()'],['../struct_smpt__ll__channel__config__ack.html#a5be7912a3f3660b47e6f68740e3a5562',1,'Smpt_ll_channel_config_ack::result()'],['../struct_smpt__ml__get__current__data__ack.html#a5be7912a3f3660b47e6f68740e3a5562',1,'Smpt_ml_get_current_data_ack::result()']]],
  ['revision',['revision',['../struct_smpt__version.html#ab01c6e281b316b1770d5646f3d3101c4',1,'Smpt_version']]],
  ['row_5flength',['row_length',['../struct_packet__input__buffer.html#a673c10744daa7bc8532bf1476e3dba17',1,'Packet_input_buffer']]]
];
