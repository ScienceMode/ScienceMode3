var searchData=
[
  ['electrode_5ferror',['electrode_error',['../struct_smpt__ll__channel__config__ack.html#af603e8f0b852c97657f30e49f34e59c8',1,'Smpt_ll_channel_config_ack::electrode_error()'],['../struct_smpt__ml__stimulation__data.html#a578cf2fccd14041c59f11bc0819e40e2',1,'Smpt_ml_stimulation_data::electrode_error()']]],
  ['electrodes',['electrodes',['../struct_smpt__ll__demux.html#afaa09c468cedea70f6b034edd867947d',1,'Smpt_ll_demux']]],
  ['enable_5fchannel',['enable_channel',['../struct_smpt__ml__update.html#a28d7ecee04a4885d2219fdffdad22ba9',1,'Smpt_ml_update']]],
  ['enable_5fdemux',['enable_demux',['../struct_smpt__ll__init.html#ad31473d103494fb855129e5c9bacfc71',1,'Smpt_ll_init::enable_demux()'],['../struct_smpt__ml__init.html#ad31473d103494fb855129e5c9bacfc71',1,'Smpt_ml_init::enable_demux()'],['../struct_smpt__ml__channel__config.html#ad31473d103494fb855129e5c9bacfc71',1,'Smpt_ml_channel_config::enable_demux()']]],
  ['enable_5fdenervation',['enable_denervation',['../struct_smpt__ll__init.html#a1b035808d89524fae23b7ecb8b2e7b66',1,'Smpt_ll_init']]],
  ['enable_5fstimulation',['enable_stimulation',['../struct_smpt__ll__channel__config.html#ad9ae19811ecaef20e6f5ce0739a2f6eb',1,'Smpt_ll_channel_config']]]
];
