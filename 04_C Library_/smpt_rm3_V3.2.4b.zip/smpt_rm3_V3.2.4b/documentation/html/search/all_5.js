var searchData=
[
  ['firmware_20changes',['Firmware changes',['../firmware_changes.html',1,'']]],
  ['fw_5fversion',['fw_version',['../struct_smpt__uc__version.html#ad49e173480a09d2fe41b79cbd4edccad',1,'Smpt_uc_version']]]
];
