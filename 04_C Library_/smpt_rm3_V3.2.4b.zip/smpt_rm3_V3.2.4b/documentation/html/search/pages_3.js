var searchData=
[
  ['mid_2dlevel_20stimulation',['Mid-level stimulation',['../mid_level.html',1,'']]]
];
