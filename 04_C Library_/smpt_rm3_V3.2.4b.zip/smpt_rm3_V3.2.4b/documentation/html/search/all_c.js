var searchData=
[
  ['new_5fack_5favailable',['new_ack_available',['../struct_smpt__cmd__list.html#ad1fdf6b170ecbfd48a86720a823c35e6',1,'Smpt_cmd_list']]],
  ['number_5fof_5fexpected',['number_of_expected',['../struct_smpt__cmd__list.html#adca70e930551d0921731fd78ebbc99b5',1,'Smpt_cmd_list']]],
  ['number_5fof_5fpoints',['number_of_points',['../struct_smpt__ll__channel__config.html#a31c93d350afab0e776a77278f487ae46',1,'Smpt_ll_channel_config::number_of_points()'],['../struct_smpt__ml__channel__config.html#a31c93d350afab0e776a77278f487ae46',1,'Smpt_ml_channel_config::number_of_points()']]],
  ['number_5fof_5frows',['number_of_rows',['../struct_packet__input__buffer.html#ad0e02d845ca7baa0725da6c7bc85186d',1,'Packet_input_buffer']]]
];
