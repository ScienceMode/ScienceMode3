var searchData=
[
  ['serial_5fport_5fhandle_5f',['serial_port_handle_',['../struct_smpt__device.html#a909a088726a1b165dbe44da15e9ff8a5',1,'Smpt_device']]],
  ['serial_5fport_5fname',['serial_port_name',['../struct_smpt__device.html#ac53ef59031bcb2ba71f716881a83815f',1,'Smpt_device']]],
  ['smpt_5fversion',['smpt_version',['../struct_smpt__uc__version.html#afc553df967273433037c54d604405524',1,'Smpt_uc_version']]],
  ['softstart',['softstart',['../struct_smpt__ml__update.html#a472b627a9243b93ba67b7a535b1dc6c8',1,'Smpt_ml_update']]],
  ['stim_5fstatus',['stim_status',['../struct_smpt__get__stim__status__ack.html#aa8b0dc430440864fd61f64596e797e2c',1,'Smpt_get_stim_status_ack']]],
  ['stimulation_5fdata',['stimulation_data',['../struct_smpt__ml__get__current__data__ack.html#ae01177aa42ae5ab66ad785612b0a7bd9',1,'Smpt_ml_get_current_data_ack']]],
  ['stimulation_5fstate',['stimulation_state',['../struct_smpt__ml__stimulation__data.html#a66d06f0ef2d41e93cb65eaf327bd6f9e',1,'Smpt_ml_stimulation_data']]]
];
